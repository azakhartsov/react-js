import React, { useEffect, useState } from "react";

function SelectHandler(event) {
  const [data, setData] = useState([]);
  console.log(event);

  //   useEffect(() => {
  //     fetch(
  //       "https://jsonplaceholder.typicode.com/posts/" +
  //         event.target.value +
  //         "/comments"
  //     )
  //       .then((response) => response.json())
  //       .then((data) => {
  //         // console.log(data);
  //         setData(data);
  //       });
  //   }, [event.target.value]);

  return (
    <>
      <select onChange={SelectHandler}>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
      </select>
      <div>
        <h1>Comments</h1>
        {data.map((item, index) => (
          <section key={item.id}>
            <p>
              <b>
                {index + 1}. {item.email}
              </b>
            </p>
            <p>{item.body}</p>
          </section>
        ))}
      </div>
    </>
  );
}
export default SelectHandler;
